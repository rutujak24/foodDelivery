# Restaurant Landing Page

- Used bootstrap tools & own styles.
- Implemented responsive template.

👉🏻 [Demo](https://yaninatrekhleb.github.io/restaurant-website/)

![Demo](img/demo.gif)